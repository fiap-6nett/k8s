#!/bin/bash

echo "Criando namespace fase4..."
kubectl apply -f namespace.yaml

echo "Aplicando Secrets..."
kubectl apply -f secrets/

echo "Aplicando ConfigMaps..."
kubectl apply -f configmaps/

echo "Aplicando PersistentVolumeClaims..."
kubectl apply -f pvc/

echo "Aplicando Services..."
kubectl apply -f services/

echo "Aplicando Deployments..."
kubectl apply -f deployments/

echo "Deploy concluído com sucesso!"
